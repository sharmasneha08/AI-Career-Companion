import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import QuestionCard from "./components/QuestionCard";
import AnswerBox from "./components/AnswerBox";

function InterviewCoach() {
  const navigate = useNavigate();

  const [role, setRole] = useState("");
  const [questions, setQuestions] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answer, setAnswer] = useState("");
  const [feedback, setFeedback] = useState(null);
  const [loading, setLoading] = useState(false);

  const generate = async () => {
    if (!role.trim()) {
      alert("Please enter a target role.");
      return;
    }

    const formData = new FormData();
    formData.append("role", role);

    try {
      setLoading(true);

      const response = await axios.post(
        "http://127.0.0.1:8000/generate_questions",
        formData
      );

      setQuestions(response.data.questions);
      setCurrentIndex(0);
      setAnswer("");
      setFeedback(null);
    } catch (error) {
      console.log(error);

      if (error.response) {
        alert(error.response.data.detail);
      } else {
        alert("Server not running");
      }
    } finally {
      setLoading(false);
    }
  };

  const submitAnswer = async () => {
    if (!answer.trim()) {
      alert("Please type your answer.");
      return;
    }

    const formData = new FormData();
    formData.append("answer", answer);

    try {
      setLoading(true);

      const response = await axios.post(
        "http://127.0.0.1:8000/evaluate_answer",
        formData
      );

      setFeedback(response.data);
    } catch (error) {
      console.log(error);

      if (error.response) {
        alert(error.response.data.detail);
      } else {
        alert("Server not running");
      }
    } finally {
      setLoading(false);
    }
  };

  const nextQuestion = () => {
    setCurrentIndex(currentIndex + 1);
    setAnswer("");
    setFeedback(null);
  };

  return (
    <div className="container fade-up">

      <h1>🎤 AI Interview Coach</h1>

      <p
        style={{
          textAlign: "center",
          color: "#cbd5e1",
          marginBottom: "30px",
        }}
      >
        Practice AI-generated interview questions and improve your confidence.
      </p>

      <div className="card">

        <input
          placeholder="Target Role (Example: Data Analyst)"
          value={role}
          onChange={(e) => setRole(e.target.value)}
        />

        <br />

        <button
          onClick={generate}
          disabled={loading}
        >
          {loading ? "Generating..." : "🚀 Generate Questions"}
        </button>

        <br />

        <button
          onClick={() => navigate("/dashboard")}
        >
          ⬅ Back to Dashboard
        </button>

      </div>

      {questions.length > 0 && currentIndex < questions.length && (

        <div
          className="card"
          style={{ marginTop: "35px" }}
        >

          <h2>
            Question {currentIndex + 1} of {questions.length}
          </h2>

          <QuestionCard
            question={questions[currentIndex]}
          />

          <AnswerBox
            value={answer}
            setValue={setAnswer}
          />

          <button
            onClick={submitAnswer}
            disabled={loading}
          >
            {loading ? "Evaluating..." : "✅ Submit Answer"}
          </button>

          {feedback && (
            <>

              <hr />

              <h2
                style={{
                  color: "#60a5fa",
                }}
              >
                Score: {feedback.score}/10
              </h2>

              <p>{feedback.feedback}</p>

              {currentIndex < questions.length - 1 ? (
                <button
                  onClick={nextQuestion}
                >
                  Next Question →
                </button>
              ) : (
                <h2
                  style={{
                    color: "#22c55e",
                  }}
                >
                  🎉 Interview Completed!
                </h2>
              )}

            </>
          )}

        </div>

      )}

    </div>
  );
}

export default InterviewCoach;