import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import toast from "react-hot-toast";

function Login() {
  const navigate = useNavigate();

  const [type, setType] = useState("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const submit = async () => {
    try {
      let response;

      if (type === "register") {
        response = await axios.post(
          "http://127.0.0.1:8000/register",
          {
            name,
            email,
            password,
          }
        );

        toast.success(response.data.message);

        setType("login");
        setName("");
        setEmail("");
        setPassword("");
      } else {
        response = await axios.post(
          "http://127.0.0.1:8000/login",
          {
            name: "",
            email,
            password,
          }
        );

        // Save Login Data
        localStorage.setItem("token", response.data.token);
        localStorage.setItem("username", response.data.name);
        localStorage.setItem("email", email);

        toast.success(`Welcome ${response.data.name} 🎉`);

        navigate("/dashboard");
      }
    } catch (error) {
      console.log(error);

      if (error.response) {
        toast.error(error.response.data.detail);
      } else {
        toast.error("Server not running");
      }
    }
  };

  return (
    <div
      className="container fade-up"
      style={{
        maxWidth: "500px",
      }}
    >
      <div className="card">

        <h1
          style={{
            marginBottom: "10px",
            textAlign: "center",
          }}
        >
          🤖 AI Career Companion
        </h1>

        <p
          style={{
            textAlign: "center",
            marginBottom: "30px",
            color: "#dbeafe",
          }}
        >
          {type === "login"
            ? "Welcome back! Login to continue."
            : "Create your AI Career account."}
        </p>

        {type === "register" && (
          <input
            type="text"
            placeholder="👤 Full Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        )}

        <input
          type="email"
          placeholder="📧 Email Address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="🔒 Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button
          onClick={submit}
          style={{
            width: "100%",
            marginTop: "20px",
          }}
        >
          {type === "login"
            ? "🚀 Login"
            : "✨ Create Account"}
        </button>

        <p
          style={{
            textAlign: "center",
            marginTop: "20px",
          }}
        >
          {type === "login"
            ? "New here?"
            : "Already have an account?"}
        </p>

        <button
          onClick={() =>
            setType(
              type === "login"
                ? "register"
                : "login"
            )
          }
          style={{
            width: "100%",
            background:
              "linear-gradient(90deg,#2563eb,#7c3aed)",
          }}
        >
          {type === "login"
            ? "Create New Account"
            : "Back to Login"}
        </button>

      </div>
    </div>
  );
}

export default Login;