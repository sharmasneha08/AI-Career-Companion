import "react-circular-progressbar/dist/styles.css";
import { CircularProgressbar, buildStyles } from "react-circular-progressbar";

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function JobMatch() {
  const navigate = useNavigate();

  const [resume, setResume] = useState(null);
  const [job, setJob] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const checkMatch = async () => {
    if (!resume || !job.trim()) {
      alert("Upload a resume and enter a job description.");
      return;
    }

    const formData = new FormData();
    formData.append("resume", resume);
    formData.append("job_description", job);

    try {
      setLoading(true);

      const response = await axios.post(
        "http://127.0.0.1:8000/match_job",
        formData
      );

      setResult(response.data);
    } catch (error) {
      console.log(error);

      if (error.response) {
        alert(error.response.data.detail);
      } else {
        alert("Server not running");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container fade-up">

      <h1>💼 AI Job Match</h1>

      <p
        style={{
          textAlign: "center",
          color: "#cbd5e1",
          marginBottom: "30px",
        }}
      >
        Compare your resume with a job description using AI.
      </p>

      <div className="card">

        <input
          type="file"
          accept=".pdf"
          onChange={(e) => setResume(e.target.files[0])}
        />

        <br />

        <textarea
          rows="8"
          placeholder="Paste Job Description Here..."
          value={job}
          onChange={(e) => setJob(e.target.value)}
        />

        <br />

        <button
          onClick={checkMatch}
          disabled={loading}
        >
          {loading ? "Checking..." : "🚀 Analyze Match"}
        </button>

        <br />

        <button
          onClick={() => navigate("/dashboard")}
        >
          ⬅ Back to Dashboard
        </button>

      </div>

      {result && (

        <div
          className="card"
          style={{ marginTop: "35px" }}
        >

          <div
style={{
width:180,
height:180,
margin:"25px auto"
}}
>

<CircularProgressbar
value={result.match_percentage}
text={`${result.match_percentage}%`}
styles={buildStyles({
pathColor:"#3b82f6",
trailColor:"rgba(255,255,255,.15)",
textColor:"#fff",
textSize:"16px"
})}
/>

</div>

<h2
style={{
textAlign:"center",
marginBottom:"20px"
}}
>
Job Match Score
</h2>
          <hr />

          <h3>✅ Matched Skills</h3>

          {result.matched_skills.length === 0 ? (
            <p>No matching skills.</p>
          ) : (
            result.matched_skills.map((skill, index) => (
              <p key={index}>✔ {skill}</p>
            ))
          )}

          <hr />

          <h3>❌ Missing Skills</h3>

          {result.missing_skills.length === 0 ? (
            <p>Great! No missing skills.</p>
          ) : (
            result.missing_skills.map((skill, index) => (
              <p key={index}>➕ {skill}</p>
            ))
          )}

          <hr />

          <h3>💡 AI Recommendation</h3>

          <p>{result.recommendation}</p>

        </div>

      )}

    </div>
  );
}

export default JobMatch;