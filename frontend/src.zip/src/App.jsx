import { Routes, Route, Navigate } from "react-router-dom";

import Login from "./Login";
import Dashboard from "./Dashboard";
import ResumeAnalyzer from "./ResumeAnalyzer";
import JobMatch from "./JobMatch";
import InterviewCoach from "./InterviewCoach";

function PrivateRoute({ children }) {
  const token = localStorage.getItem("token");
  return token ? children : <Navigate to="/login" replace />;
}

function App() {
  const token = localStorage.getItem("token");

  return (
    <Routes>
      <Route
        path="/"
        element={<Navigate to={token ? "/dashboard" : "/login"} replace />}
      />

      <Route path="/login" element={<Login />} />

      <Route
        path="/dashboard"
        element={
          <PrivateRoute>
            <Dashboard />
          </PrivateRoute>
        }
      />

      <Route
        path="/resume"
        element={
          <PrivateRoute>
            <ResumeAnalyzer />
          </PrivateRoute>
        }
      />

      <Route
        path="/job-match"
        element={
          <PrivateRoute>
            <JobMatch />
          </PrivateRoute>
        }
      />

      <Route
        path="/interview"
        element={
          <PrivateRoute>
            <InterviewCoach />
          </PrivateRoute>
        }
      />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default App;